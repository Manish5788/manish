sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("netlify.Netlify_App.controller.Netlify_View", {
		onInit: function () {

		}
	});
});