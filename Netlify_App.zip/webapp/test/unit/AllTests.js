sap.ui.define([
	"netlify/Netlify_App/test/unit/controller/Netlify_View.controller"
], function () {
	"use strict";
});